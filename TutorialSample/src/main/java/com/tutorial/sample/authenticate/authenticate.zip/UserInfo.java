/**
 * 
 */
package com.tutorial.sample.authenticate;

/**
 * @author Marcelo
 *
 */
public class UserInfo {

	String name;
	String id;
	String password;
	
	public UserInfo(String name, String id, String password) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.id = id;
		this.password = password;
	}
}

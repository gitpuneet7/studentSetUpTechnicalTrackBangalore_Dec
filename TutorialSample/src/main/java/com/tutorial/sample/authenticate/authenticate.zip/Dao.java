/**
 * 
 */
package com.tutorial.sample.authenticate;

/**
 * @author Marcelo
 *
 */
public class Dao {

	public UserInfo getUser(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
